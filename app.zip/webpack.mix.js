import mix from 'laravel-mix';
mix.browserSync('127.0.0.1:8000');