<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white p-6 rounded-lg shadow-md">
        <h3 class="text-2xl font-bold text-gray-800 mb-4">Selamat datang, <?php echo e(Auth::user()->name); ?>!</h3>
        <p class="text-gray-600">Ini adalah halaman dashboard Anda. Gunakan menu di samping untuk mengelola konten Anda.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aji.setiaji\Documents\FREELANCE\profile_smarlabz\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>