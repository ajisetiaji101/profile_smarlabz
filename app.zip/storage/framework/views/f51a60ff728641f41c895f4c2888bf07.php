

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-20 max-w-4xl">

        
        <nav class="mb-6 text-sm text-gray-500 flex items-center space-x-1">
            <a href="<?php echo e(url('/')); ?>" class="hover:text-orange-600 transition">Home</a>
            <span>/</span>
            <a href="<?php echo e(url('/blogs')); ?>" class="hover:text-orange-600 transition">Blog</a>
            <span>/</span>
            <span class="text-gray-700 font-medium"><?php echo e($blog->title); ?></span>
        </nav>

        
        <header class="text-center mb-10">
            <h1 class="text-4xl md:text-5xl font-extrabold text-gray-900 leading-tight mb-4 animate-fadeIn">
                <?php echo e($blog->title); ?>

            </h1>
            <p class="text-gray-500 text-base">
                Diposting pada: <span class="font-medium"><?php echo e($blog->created_at->translatedFormat('d F Y')); ?></span>
            </p>
        </header>

        
        <?php if($blog->image): ?>
            <figure class="mb-10">
                <img src="<?php echo e($blog->image); ?>" alt="<?php echo e($blog->title); ?>"
                    class="w-full h-64 object-cover rounded-xl shadow-xl hover:scale-105 transition duration-500">
            </figure>
        <?php endif; ?>

        
        <article class="ql-editor prose lg:prose-xl max-w-none text-gray-700 mx-auto">
            <?php echo $blog->content; ?>

        </article>

        
        <div class="mt-12 text-center">
            <a href="<?php echo e(url('/blogs')); ?>"
                class="inline-flex items-center px-6 py-3 border border-gray-300 rounded-full text-gray-700 font-medium hover:bg-orange-50 transition duration-300 shadow-sm focus:outline-none focus:ring-2 focus:ring-orange-200">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Kembali ke Daftar Blog
            </a>
        </div>

        
        <?php if(isset($relatedBlogs) && $relatedBlogs->count()): ?>
            <section class="mt-20">
                <h2 class="text-2xl font-bold mb-6 text-gray-900">Baca Juga</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300 bg-white flex flex-col">
                            <img src="<?php echo e($rel->image); ?>" alt="<?php echo e($rel->title); ?>" class="w-full h-40 object-cover">
                            <div class="p-4 flex-1 flex flex-col">
                                <h3 class="text-lg font-semibold mb-2 line-clamp-2"><?php echo e($rel->title); ?></h3>
                                <p class="text-sm text-gray-500 mb-2">
                                    <?php echo e($rel->created_at->translatedFormat('d F Y')); ?>

                                </p>
                                <a href="<?php echo e(url('/blogs/' . $rel->id)); ?>"
                                    class="mt-auto text-orange-600 hover:underline text-sm font-medium">
                                    Baca Selengkapnya →
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\aji.setiaji\Documents\FREELANCE\profile_smarlabz\resources\views/blogs/detail.blade.php ENDPATH**/ ?>